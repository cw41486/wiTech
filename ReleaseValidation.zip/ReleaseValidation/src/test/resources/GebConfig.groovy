
// Geb Config File



/*
	This is the Geb configuration file.

	See: http://www.gebish.org/manual/current/#configuration
*/


import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions

waiting {
    timeout = 10
    retryInterval = 1
}

environments {
    // run via “./gradlew chromeTest”
    // See: http://code.google.com/p/selenium/wiki/ChromeDriver
    chrome {
        driver = {
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--disable-gpu");
            new ChromeDriver(options)
        }
    }
}
// check class when pages are not found
// To run the tests with all browsers just run “./gradlew test”
