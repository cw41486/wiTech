import geb.spock.GebReportingSpec
import spock.lang.Shared
import spock.lang.Stepwise
import wiTech.Processes.*
import wiTech.Reusable
import wiTech.wiTechPages.*

@Stepwise
class ReleaseValidation extends GebReportingSpec{

    @Shared
    def properties = new Properties()
    def gsFileList = Anvil.listGSFiles(properties,'wiTECH')
    def reuse = new Reusable(driver,baseUrl,properties)
    def validate = new ValidationProcess(driver,baseUrl,properties)

    def setupSpec() {
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)
        }

        baseUrl = "${properties.getProperty('scheme')}://${properties.getProperty('diagnosticSoftware.location')}"
    }

    def "login to Discovery"(){
        when:
            at reuse.loginProcess()
        then:
            Thread.sleep(1000)
    }



    def "Select scantool"(){
        when:
            at reuse.selectTool()
        then:
            Thread.sleep(1000)
    }


    def "run validation"() {
        when:
        def failures = validate.performValidation()
        if (failures.isEmpty()) {
            reuse.log "Test successful"
        } else {
            failures.each { reuse.log it }
            driver.quit()
        }
        then:
            Thread.sleep(3000)
    }
/*
    def "Obtain release information"(){
        when:
            reuse.navigateTo('About wiTECH')
        then:
            waitFor{at AboutWitechPage}
    }

    def "print version info"(){
        setup:
            reuse.log "Client: ${witechVersion.getAt(0).text()}"
            reuse.log "Server: ${witechVersion.getAt(1).text()}"
    }
    def "Go through all tabs on topology page"(){
        when:
            reuse.navigateTo('Action Items')
        then:
            waitFor{at TopologyPage}

        when:
            allDtcTab.click()
            Thread.sleep(1000)
            $(By.xpath("//div[@class = 'table-responsive ng-scope']/table/tbody/tr[@class = 'ng-scope']")).getAt(0).click()  // click on first item
            waitFor(30){!$(By.xpath("//div[@class = 'progress-bar']")).displayed}
            report "DTC tab environment"
            Thread.sleep(1000)
            $(By.xpath("//*[text() = ' Snapshot Data']")).click()
            report "Snapshot data"
            reuse.navigateTo('Action Items')
            Thread.sleep(1000)
            allDtcTab.click()
            Thread.sleep(3000)
            $(By.xpath("//button[@class='btn btn-default']")).getAt(0).click()
            withWindow({title == 'fastSearchResults.jsp'}, close: true){
                waitFor{$(By.xpath("//td[text() = 'Service Information']")).displayed}
            }
            $(By.xpath("//button[text() = ' View Freeze Frame']")).click()
            waitFor(30){$(By.xpath("//button[text() = ' Email Report']")).displayed}
            $(By.xpath("//button[text() = ' Email Report']")).click()
            waitFor(30){$(By.xpath("//div[@class='panel-heading ng-binding']")).text() == 'Email Report'}
            $(By.xpath("//input[@placeholder = 'User ID']")).value(properties.getProperty('dealerConnect.userid'))
            $(By.xpath("//input[@placeholder = 'Email']")).value('cwenson@dcctools.com')
            Thread.sleep(1000)
            $(By.xpath("//div[text() = ' Add']")).click()
            Thread.sleep(1000)
            $(By.xpath("//div[@id = 'taTextElement7681399037255054']")).value("Geb message test.")
            Thread.sleep(1000)
            $(By.xpath("//button[text() = 'Preview Email']")).click()
            Thread.sleep(1000)
            $(By.xpath("//button[text() = ' Send Report']")).click()
            waitFor(30){$(By.xpath("//p[@class='form-control-static ng-binding']")).text() == 'Report email has been sent.'}
            $(By.xpath("//button[text() = 'OK']")).click()
        then:
            Thread.sleep(3000)

        when:
            reuse.navigateTo('Action Items')
        then:
            waitFor{at TopologyPage}

        when:
            allDtcTab.click()
            Thread.sleep(1000)
            $(By.xpath("//button[text() = ' Clear All DTCs']")).click()
            waitFor(10){$(By.xpath("//h3[@class='ng-binding']")).text() == 'Clear All DTCs'}
            $(By.xpath("//button[text() = 'Continue']")).click()
            waitFor(30){$(By.xpath("//*[text() = ' DTCs cleared!']")).displayed}
            $(By.xpath("//button[text() = 'Close']")).click()

        then:
            Thread.sleep(3000)

        when:
            allFlashesTab.click()
            Thread.sleep(10000)
            if($(By.xpath("//div[@class='mp-list-empty ng-binding ng-scope']")).displayed){
                reuse.log "Ecu's up to date"
            }
            else{
                report "List of flashes"
            }
        then:
            Thread.sleep(3000)

        when:
            recallTab.click()
            waitFor(30){$(By.xpath("//table[@class = 'mp-table mp-table-hover']"))}
            report "List of recalls"
            $(By.xpath("//table[@class = 'mp-table mp-table-hover']/tbody/tr[@class = 'ng-scope']")).getAt(0).click()
            Thread.sleep(5000)
            withWindow({$('embed#plugin')}, close: true){
                Thread.sleep(1000)
                report "Recall window"
            }
        then:
            Thread.sleep(3000)

        when:
            rrtTab.click()
            report "RRT details"
        then:
            Thread.sleep(3000)
    }

    def "Go through ECU tabs"(){
        when:
            at reuse.selectEcu('PCM')
        then:
            Thread.sleep(3000)

        when:
            $(By.xpath("//button[@class = 'btn btn-default ng-binding ng-scope']")).click()
            Thread.sleep(1000)
            $(By.xpath("//td[@class = 'mp-flash-bulletins']/div/table/tbody/tr[@class = 'ng-scope']")).click()
            Thread.sleep(10000)
            withWindow({$('embed#plugin')},close: true){
                Thread.sleep(1000)
                report "Service bulletin"
            }
            Thread.sleep(1000)
            DtcTab.click()
        then:
            Thread.sleep(3000)

        when:
            $(By.xpath("//div[@class = 'table-responsive ng-scope']/table/tbody/tr[@class = 'ng-scope']")).getAt(0).click()  // click on first item
            waitFor(30){!$(By.xpath("//div[@class = 'progress-bar']")).displayed}
            report "DTC tab environment"
            Thread.sleep(1000)
            $(By.xpath("//*[text() = ' Snapshot Data']")).click()
            report "Snapshot data"
            reuse.selectEcu('PCM')
            Thread.sleep(3000)
            $(By.xpath("//button[@class='btn btn-default']")).getAt(0).click()
            withWindow({title == 'fastSearchResults.jsp'}, close: true){
                waitFor{$(By.xpath("//td[text() = 'Service Information']")).displayed}
            }
            $(By.xpath("//button[text() = ' View Freeze Frame']")).click()
            waitFor(30){$(By.xpath("//button[text() = ' Email Report']")).displayed}
            $(By.xpath("//button[text() = ' Email Report']")).click()
            waitFor(30){$(By.xpath("//div[@class='panel-heading ng-binding']")).text() == 'Email Report'}
            $(By.xpath("//input[@placeholder = 'User ID']")).value(properties.getProperty('dealerConnect.userid'))
            $(By.xpath("//input[@placeholder = 'Email']")).value('cwenson@dcctools.com')
            Thread.sleep(1000)
            $(By.xpath("//div[text() = ' Add']")).click()
            Thread.sleep(1000)
            $(By.xpath("//div[@id = 'taTextElement7681399037255054']")).value("Geb message test.")
            Thread.sleep(1000)
            $(By.xpath("//button[text() = 'Preview Email']")).click()
            Thread.sleep(1000)
            $(By.xpath("//button[text() = ' Send Report']")).click()
            waitFor(30){$(By.xpath("//p[@class='form-control-static ng-binding']")).text() == 'Report email has been sent.'}
            $(By.xpath("//button[text() = 'OK']")).click()
            Thread.sleep(3000)
            $(By.xpath("//button[text() = ' Clear All DTCs']")).click()
            waitFor(10){$(By.xpath("//h3[@class='ng-binding']")).text() == 'Clear All DTCs'}
            $(By.xpath("//button[text() = 'Continue']")).click()
            waitFor(30){$(By.xpath("//*[text() = ' DTCs cleared!']")).displayed}
            $(By.xpath("//button[text() = 'Close']")).click()
        then:
            Thread.sleep(3000)

        when:
            DataTab.click()
            waitFor{graphIcon}
            for(int x = 0;x < 3;x++) {
                graphIcon.getAt(x).click()
                Thread.sleep(1000)
            }
            graphSelect.click()
            waitFor(30){at GraphPage}
            report "Graph displayed"
            exitButton.click()
        then:
            Thread.sleep(3000)

        when:
            MiscFunctionsTab.click()
            Thread.sleep(3000)
            Functions.'Check PCM VIN'.click()
            waitFor(30){$(By.xpath("//*[text() = 'Vehicle VIN is Valid']"))}
            $('button',text: contains('Close')).click()
            waitFor{MiscFunctionsTab}
        then:
            Thread.sleep(3000)

        when:
            SystemsTab.click()
            Thread.sleep(3000)

        then:
            Thread.sleep(3000)

    }
    */
}
