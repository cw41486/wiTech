package wiTech

import geb.Browser
import org.openqa.selenium.By
import org.openqa.selenium.WebElement
import org.openqa.selenium.interactions.Actions
import wiTech.wiTechPages.*
import wiTech.Processes.*

class Reusable extends Browser{

    def properties

    // Constructor
    Reusable(driver,baseUrl, properties){
        this.driver = driver
        this.baseUrl = baseUrl
        this.properties = properties
    }

    def log(x) {println "${new Date()} - ${x}"}


    def selectTool(){
        def discoveryPage = new DiscoveryPage()
        discoveryPage.vinNumber = properties.getProperty("vehicle.vin")
        at discoveryPage
        try{
            def update = $(By.xpath("//*[text() = 'Device Update Available']")).displayed
            if(update){
                report "Update appeared"
                $(By.xpath("//button[text()=' Continue']")).click()
                Thread.sleep(5000)
                withWindow({title == 'Device Manager'},page: DeviceManagerPage, close: true){
                    report "Update information"
                    updateNowButton.click()
                    Thread.sleep(3000)
                    waitFor(60*12){$(By.xpath("//i[@class = 'fa fa-check-square dm-update-status-completed-icon']")).displayed}
                    $(By.xpath("//button[text() ='OK']")).click()
                }
            }
            else{}
        }
        catch(Throwable t){reuse.log "${t.message}"}
        try {
            def enterVin = $(By.xpath("//button[text() = ' Enter VIN']")).displayed
            report "Enter vin appeared"
            if (enterVin) {
                $(By.xpath("//button[text() = ' Enter VIN']")).click()
                Thread.sleep(3000)
                $(By.xpath("//input[@name='manEntryVin']")).value(properties.getProperty("vehicle.vin"))
                Thread.sleep(1000)
                $(By.xpath("//button[text() = 'Submit']")).click()
                Thread.sleep(1000)
                waitFor(30) { toolSelect }
            } else { }
        }
        catch(Throwable t){reuse.log "${t.message}"}
        try{
            if($(By.xpath("//div[text() = 'Vehicle in use by: Initial scan']")).displayed){
                log "Vehicle in initial scan phase"
                def exit = 0
                while($(By.xpath("//div[text() = 'Vehicle in use by: Initial scan']")).displayed && (exit < 300)){  // exit after 5 minutes
                    Thread.sleep(1000)
                    exit++
                }
                log "Scanning completed. Took ${exit} seconds"
            }
            else{}

        }
        catch(Throwable t){log "${t.message}"}
        Thread.sleep(5000)
        toolSelect.click()
        Thread.sleep(10000)
        report "vehicle Proxi message"
        def displayed = $(By.xpath("//*[contains(text(), 'It has been detected that there is a proxi configuration issue on this vehicle.')]")).displayed
        report "cancel Proxi message"
        !displayed || $(By.xpath("//button[contains(text(), 'Cancel')]")).click()
        Thread.sleep(3000)
        return TopologyPage
    }

    def selectEcu(module){

        def year = properties.getProperty('vehicle.year')
        def temp = new ECUPage()
        def model = properties.getProperty('vehicle.model')
        temp.ecu = module
        if(model == "BU"&& year=="2015"){
            if(module=="HVAC"){
                temp.flashFile = "838077     -03-0000       -2213"
            }
            else if(module=="ABS"){
                temp.flashFile = "EPB01014B7C-44-KJEA17ER_07-5101"
            }
            else{
                temp.flashFile = properties.getProperty("flashFile.name").substring(0, properties.getProperty('flashFile.name').length()-4).toUpperCase()
            }
        }
        else{
            temp.flashFile = properties.getProperty("flashFile.name").substring(0, properties.getProperty('flashFile.name').length()-4).toUpperCase()
        }
        navigateTo("ECU List")
        at ECUListPage
        Thread.sleep(5000)
        $(By.xpath("//*[text() = '${module}']")).click()       // Dynamic selection of the ECU.
        return temp
    }


    def loginProcess(){
        try{

            def serialNumber = properties.getProperty('scanTool.serialNumber')
            to LoginPage
            Thread.sleep(10000)
            assert username.size() == 1
            assert pwd.size() == 1
            assert dealerCode.size() == 1
            assert signIn.size() == 1
            username.value(properties.getProperty('dealerConnect.userid'))
            pwd.value(properties.getProperty('dealerConnect.password'))
            dealerCode.value(properties.getProperty('dealerConnect.dealerCode'))
            if(properties.getProperty('dealerConnect.userid') == '0026793.d532') {
                $(By.xpath("//*[text() = 'Link-E-Entry']")).click()
            }
            signIn.click()
            Thread.sleep(10000)
            def displayed = $(By.xpath("//*[text() = 'Select a wiTECH Environment']")).displayed
            !displayed || $(By.xpath("//*[text() = '${serialNumber}']")).click()
            waitFor(30){at EulaPage}
            acceptButton.click()
            waitFor(30){at DiscoveryPage}
            return DiscoveryPage
        }
        catch(e){
            println(e)
            return false
        }
    }

    def doFlashProcess(){
        def failures = []
        def waitUntil = new Date().time + (1000 * 60 * 25)
        while((!$(By.xpath("//*[contains(text(),'Successfully flashed ECU')]")).displayed)&&(new Date().time < waitUntil)){
            Thread.sleep(10000)
            def userAgreement = $(By.xpath("//input[@name='userAgree']"))
            def continueElement = $(By.xpath("//button[contains(text(),'Continue')]"))
            def okElement = $(By.xpath("//button[contains(text(), 'OK')]"))
            if(userAgreement.displayed){
                try{
                    userAgreement.click()
                    $(By.xpath("//button[contains(text(),'Flash ECU')]")).click()
                    waitFor(60){$(By.xpath("//button[contains(text(),'OK')]"))}
                    $(By.xpath("//button[contains(text(),'OK')]")).click()
                }
                catch(e){}
            }
            else if($(By.xpath("//*[contains(text(), 'Please Turn the Ignition Key OFF')]")).size()==1){
                report "Ignition Off message"
                Thread.sleep(3000)
                if(continueElement){continueElement.click()}
                else{okElement.click()}
            }

            else if($(By.xpath("//*[contains(text(), 'Please Turn the Ignition Key ON')]")).size()==1){
                report "Ignition on message"
                Thread.sleep(3000)
                if(continueElement){continueElement.click()}
                else{okElement.click()}
            }
            else if(continueElement.displayed){
                Thread.sleep(5000)
                try{
                    continueElement.click()
                }
                catch(e){}
            }
            else if(okElement.displayed){
                Thread.sleep(5000)
                try{
                    okElement.click()
                }
                catch(e){}
            }
            else{}
        }
        if(!$(By.xpath("//*[contains(text(), 'Successfully flashed ECU')]")).displayed){
            failures << "Flash failed or did not complete within 25m"
        }
        return failures
    }

    def getEcuPage(ecu){
        def temp = new ECUPage()
        def model = properties.getProperty('vehicle.model')
        def year = properties.getProperty('vehicle.year')
        temp.ecu = ecu
        if(model=="BU"&&year=="2015"){
            if(ecu=="HVAC"){
                temp.flashFile = "838077     -03-0000       -2213"
            }
            else if(ecu=="ABS"){
                temp.flashFile = "EPB01014B7C-44-KJEA17ER_07-5101"
            }
            else{
                temp.flashFile = properties.getProperty("flashFile.name").substring(0, properties.getProperty('flashFile.name').length()-4).toUpperCase()
            }
        }
        else{
            temp.flashFile = properties.getProperty("flashFile.name").substring(0, properties.getProperty('flashFile.name').length()-4).toUpperCase()
        }
        return temp
    }

    def List getEcus(){
        def ecuXmlData = []
        gsFileList.each{filename ->
            if(filename =~ "getEcuData") {
                ecuXmlData.add(Anvil.getGSFile(filename, properties, 'wiTECH'))
            }
            else{

            }
        }
        return ecuXmlData.EcuData[0].acronym.collect{it}
    }

    def navigateTo(location){
        def x = 0
        def menuOptions= ["VEHICLE", "ACTIVITIES", "UTILITIES", "ANALYSIS", "RESOURCES", "HELP", "ME", "SYSTEM"]
        def locationXpath = "//a[text() = '${location}']"

        Actions action = new Actions(driver)
        WebElement element = driver.findElement(By.xpath(locationXpath))
        $(By.xpath("//*[contains(@ng-click, 'toggleAppMenu()')]")).click()

        Thread.sleep(3000)

        if($(By.xpath("//i[@class = 'fa mp-nav-caret fa-caret-down']"))){
            while($(By.xpath("//i[@class = 'fa mp-nav-caret fa-caret-down']"))){
                $(By.xpath("//i[@class = 'fa mp-nav-caret fa-caret-down']")).getAt(0).click()
            }}
        else{}
        Thread.sleep(1000)
        while(!element.isDisplayed() && menuOptions[x]!= null){
            try {
                if ($(By.xpath("//h4[text() = '${menuOptions[x]}']"))) {
                    $(By.xpath("//h4[text() = '${menuOptions[x]}']")).click()

                } else {
                    println "${menuOptions[x]} was not able to be clicked."
                }
            } catch(Throwable t){ log t.message }

            Thread.sleep(1000)
            x++
        }
        if(menuOptions[x] == null){
            println "Unable to find ${location}"

        }
        else{
            action.moveToElement(element,3,3).click().perform()       // give a slight offset to click on.
        }
        Thread.sleep(1000)
        try {
            if (element.displayed) {
                def y = 0
                log "still visible, trying again"
                while (element.isDisplayed()) {
                    $(By.xpath("//i[@class='fa mp-nav-caret fa-caret-up']")).getAt(y).click()
                    Thread.sleep(1000)
                    action.moveToElement(element, 3, 3).click().perform()
                    y++
                    Thread.sleep(1000)
                }
            } else {
            }
        } catch(Throwable t){ log "successfully clicked on ${location}" }
    }


}


