package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By

class DiscoveryPage extends Page {

     static def vinNumber
     static def toolName


    // Search for Tool based on xpath (this is temporary)
    static at = { $(By.xpath("//h3[text()=' Vehicle Selection']")).displayed }

    static content = {

        updateButton(required: false) {$(By.xpath("//*[text() = ' Continue']"))}
        updateMessage(required: false) {$(By.xpath("//*[text() = 'Device Update Available']"))}
        toolSelect(wait: true){$("span.mp-discovery-info-value.ng-binding", text: contains(vinNumber))}
        selectName(wait: true){$('span', text: contains(toolName.toString.replaceAll('-',' ')))}
        devMan{$(By.xpath("//i[@class='fa fa-cog pull-right']"))}
        trigger{$("button",text: contains("Trigger Recording"))}
        exitRecording{$("button",text: contains("Exit Recording Mode"))}

    }
}
