package wiTech.wiTechPages
import geb.Page
import wiTech.wiTechModules.*


class ModulePage extends Page{



    static at = {title == "wiTECH"}

    static content = {

        tab{module EcuModule}
    }

}
