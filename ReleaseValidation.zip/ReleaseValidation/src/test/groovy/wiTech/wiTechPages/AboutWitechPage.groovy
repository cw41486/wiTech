package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By

/**
 * Created by cwenson on 4/13/2016.
 */
class AboutWitechPage extends Page{

    static at = {$('h3').getAt(0).text() == 'About wiTECH'}

    static content = {
            witechVersion {$(By.xpath("//div[@class = 'col-xs-12 col-sm-6 col-md-6 col-lg-6']/table/tbody/tr/td[@class = 'mp-padding-5']"))}
            deviceInfo {$(By.xpath("//div[@class = 'col-xs-12 col-sm-6 col-md-6 col-lg-6 ng-scope']/table/tbody/tr/td[@class = 'mp-padding-5']"))}
           }
}
