package wiTech.wiTechPages

import geb.Page

class EulaPage extends Page {

    static at = { title == "wiTECH Login" }

    static content = {
        acceptButton { $("button", text: "Accept") }
    }
}
