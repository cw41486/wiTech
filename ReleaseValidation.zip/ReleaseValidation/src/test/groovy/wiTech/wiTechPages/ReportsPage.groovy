package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By

/**
 * Created by cwenson on 4/19/2016.
 */
class ReportsPage extends Page{

    static at = {$(By.xpath("//h3[text() = ' Reports']")).displayed}

    static content = {

        // Main page elements

            freezeFrameReport{$(By.xpath("//*[text() = 'Freeze Frame Report']"))}
            configReport{$(By.xpath("//*[text() = 'Configuration Report']"))}
            eventDataReport{$(By.xpath("//*[text() = 'Event Data Report']"))}
            ecuDetailsReport{$(By.xpath("//*[text() = 'ECU Details Report']"))}
            vehicleHealthReport{$(By.xpath("//*[text() = 'Vehicle Health Report']"))}
            vehicleScanReport{$(By.xpath("//*[text() = 'Vehicle Scan Report']"))}
            newCustomReportButton{$(By.xpath("//button[contains(text()='New Custom Report')]"))}

        // Indiviual page elements
            pageElements {$("div", class: "col-md-10 col-sm-10 col-xs-10 mp-report-section-title-double")}
    }

}
