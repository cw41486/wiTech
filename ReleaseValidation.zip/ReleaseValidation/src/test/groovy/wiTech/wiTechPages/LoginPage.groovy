package wiTech.wiTechPages

import geb.Page

class LoginPage extends Page {

    static at = { title == "wiTECH Login" }

    static content = {
        username { $("#usernameInput") }
        pwd { $("#passwordInput") }
        dealerCode { $("#dealerCodeInput") }
        signIn { $("#signInButton") }
    }
}
