package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By



class EnvironmentPage extends Page {

    static serialNumber

    static at = { title == "WiTECH2" }

    static content = {
        test { $(By.xpath("//*[text() = 'TEST - Environment for release intent validation']"))}
        EmeaToolSelect{$(By.xpath("//*[text() = '$serialNumber']"))}
    }
}
