package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By

/**
 * Created by cwenson on 4/19/2016.
 */
class CustomerPreferencesPage extends Page{

    static at = {$(By.xpath("//h3[text()=' Customer Preferences']")).displayed}

    static content = {
        preferences{$(By.xpath("//table[@id='custPrefsTable']/tbody/tr[@class='ng-scope']/td[@class='ng-binding']"))}
    }

}


