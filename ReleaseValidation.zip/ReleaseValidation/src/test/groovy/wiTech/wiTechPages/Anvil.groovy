package wiTech.wiTechPages

import groovy.util.slurpersupport.GPathResult
import groovyx.net.http.ContentType
import groovyx.net.http.HTTPBuilder
import org.apache.commons.codec.digest.DigestUtils

import static groovyx.net.http.Method.*

class Anvil {

    static boolean ignitionOn(props) {
        def result = post(
                "${props.getProperty("anvil.serverUrl")}/vehicle/ignition/${props.getProperty("vehicle.id")}",
                [
                        securityKey: DigestUtils.shaHex(props.getProperty("anvil.testRunId") as String),
                        state      : "ON"
                ]
        )

        if (result.responseBody?.success) {
            return true
        }

        return false
    }

    static boolean ignitionOff(props) {
        def result = post(
                "${props.getProperty("anvil.serverUrl")}/vehicle/ignition/${props.getProperty("vehicle.id")}",
                [
                        securityKey: DigestUtils.shaHex(props.getProperty("anvil.testRunId") as String),
                        state      : "OFF"
                ]
        )

        if (result.responseBody?.success) {
            return true
        }

        return false
    }

    static List listGSFiles(props, software, version = 1.0) {
        def urls = []
        def result = get(
                "${props.getProperty("anvil.serverUrl")}/buckSlotConfigSet/show/${props.getProperty("vehicle.buckSlotConfigSet")}?format=json"
        )

        if (result.responseBody) {
            urls = result.responseBody.goldStandardFileList.findAll {
                it.contains("${software}/v${version}")
            }
        }

        return urls.collect { it.split("/").last() }
    }

    static GPathResult getGSFile(filename, props, software, version = 1.0) {
        def result = get(
                "${props.getProperty("anvil.serverUrl")}/gold_standards/${props.getProperty("vehicle.buckSlotConfigSet")}/${software}/v${version}/${filename}"
        )

        return result.responseBody
    }

    static post(url, postBody) {
        def map = [:]

        try {
            def httpBuilder = new HTTPBuilder(url)
            httpBuilder.request(POST) { req ->
                requestContentType = ContentType.URLENC
                body = postBody

                response.success = { res, reader ->
                    map.responseHeaders = res
                    map.responseBody = reader
                }

                response.failure = { res ->
                    map.responseHeaders = res
                }
            }
        } catch (e) {
            println e.message
            map.exception = e
        }

        return map
    }

    static get(url) {
        def map = [:]

        try {
            def httpBuilder = new HTTPBuilder(url)
            httpBuilder.request(GET) { req ->
                requestContentType = ContentType.URLENC

                response.success = { res, reader ->
                    map.responseHeaders = res
                    map.responseBody = reader
                }

                response.failure = { res ->
                    map.responseHeaders = res
                }
            }
        } catch (e) {
            println e.message
            map.exception = e
        }

        return map
    }
}
