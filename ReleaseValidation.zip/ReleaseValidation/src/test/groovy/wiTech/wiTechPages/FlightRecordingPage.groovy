package wiTech.wiTechPages
import geb.Page
import org.openqa.selenium.By


class FlightRecordingPage extends Page{


        static at = {true}

        static content = {

            templates {$(By.xpath("//tbody"))}
            viewButton {$(By.xpath("//div[@title='View']"))}
            createNewTemplate {$(By.xpath("//*[text() = 'Create New Template']"))}
            startRecording {$('button',text: contains("Start Recording"))}
            recordingsList {$(By.xpath("//tbody"))}
            recordingDropArrow {$("button",class: 'btn btn-sm btn-primary').first()}
            deleteRecording {$("button",title: contains("Delete Recording"))}

        }
}
