package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By

class DeviceManagerPage extends Page {


    static at = {true}

    def device = getDeviceName()
    def serial = getSerialNum()

    def String getSerialNum(){
        def properties = new Properties()
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)

        }
        return properties.getProperty('scanTool.serialNumber')
    }

    def String getDeviceName() {
        def properties = new Properties()
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)

        }
        return properties.getProperty('scanTool.name')
    }


    static content = {

        deviceName { $(By.xpath("//div[text() = '${device}']")) }
        serialNumber {$(By.xpath("//*[text() = '${serial}']"))}
        devDropArrow{$(By.xpath("//div[@class='dm-table-cell text-right dm-config-toggle-icon']"))}
        upArrow{$(By.xpath("//i[@class='fa fa-2x hover-hand fa-chevron-circle-up']"))}
        joinNetwork{$(By.xpath("//*[text() = 'Join other network']"))}
        manNetwork{$(By.xpath("//*[text() = 'Manage networks']"))}
        ssid{$(By.xpath("//input[@id='ssid']"))}
        pass{$(By.xpath("//input[@id='passphrase']"))}
        checkBox{$(By.xpath("//input[@type='checkbox']"))}
        cancelButton{$(By.xpath("//button[text() = 'Cancel']"))}
        connectButton{$(By.xpath("//button[text() = 'Connect']"))}
        networkConnection{$(By.xpath("//i[@ng-show = 'network.connected']"))}
        rebootButton{$(By.xpath("//button[text() = 'Reboot Device']"))}
        resetButton{$(By.xpath("//button[text() = 'Reset Device']"))}
        updateNowButton {$(By.xpath("//button[text() = 'Update Now']"))}



    }

}
