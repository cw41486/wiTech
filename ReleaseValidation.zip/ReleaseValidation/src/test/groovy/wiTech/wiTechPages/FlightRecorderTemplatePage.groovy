package wiTech.wiTechPages
import geb.Page
import org.openqa.selenium.By


class FlightRecorderTemplatePage extends Page{

        static at = {true}

        static content = {

            saveTemplate{$(By.xpath("//*[text() = 'Save Template']"))}
            deleteTemplate{$('button',text: contains("Delete Template"))}
            editTemplate{$(By.xpath("//*[text() =' Edit Template']"))}
            backToList{$(By.xpath("//*[text() =' Back To List']"))}
            nameBox{$(By.xpath("//input[@placeholder='Enter template name...']"))}
            description{$(By.xpath("//input[@placeholder='Enter a description...']"))}
            yearList{$(By.xpath("/html/body/div/div[1]/div[2]/div/div/div/div[6]/div/div[1]/div[2]/div[1]/div/ul"))}
            yearButton{$(By.xpath("/html/body/div/div[1]/div[2]/div/div/div/div[6]/div/div[1]/div[2]/div[1]/div/button"))}
            bodyButton{$(By.xpath("/html/body/div/div[1]/div[2]/div/div/div/div[6]/div/div[1]/div[2]/div[2]/div/button"))}
            bodyList{$(By.xpath("/html/body/div/div[1]/div[2]/div/div/div/div[6]/div/div[1]/div[2]/div[2]/div/ul"))}
            ecuButton{$(By.xpath("/html/body/div/div[1]/div[2]/div/div/div/div[6]/div/div[1]/div[2]/div[3]/div/button"))}
            ecuDropdown{$(By.xpath("/html/body/div/div[1]/div[2]/div/div/div/div[6]/div/div[1]/div[2]/div[3]/div/ul"))}
            elementList{$(By.xpath("//*[@id = 'available-items-scroller']"))}
            add{$(By.xpath("//*[text() = 'Add']"))}
            remove{$(By.xpath("//*[text() = 'Remove']"))}


        }

}
