package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By

//This is a page object for the "ECU List" page. you can get there in wiTECH 2 by connecting to a vehicle and then selecting the menu button and then sellecting "ECU List"
class ECUListPage extends Page {

    static at = { title == "wiTECH" }

    def ecus = getEcus()// I Initialize the list of ECUs here based on the GS data


    //all this does is return a list containing all the ECUs on the BUCK per the gold standard data. It works like a charm.
    def List getEcus(){
        def properties = new Properties()
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)
        }
        def gsFileList = Anvil.listGSFiles(properties,'wiTECH')
        def ecuXmlData = []
        gsFileList.each{filename ->
            if(filename =~ "getEcuData") {
                ecuXmlData.add(Anvil.getGSFile(filename, properties, 'wiTECH'))
            }
            else{

            }
        }
        return ecuXmlData.EcuData[0].acronym.collect{it}
    }

    def boolean ecuExists(String ecu){
        return ecus.contains(ecu)
    }
    //this is the area I am not sure about and basically the only snipit of code I have yet to change.
    //I want to define an element for each ECU based on the the GS data. so that on the top level script all you have to say is for example PCM.click()
    //Let me know if you have any questions on wat I have tried so far etc.
    static content = {
        ecus.each{ ecu ->
            "${ecu}" {$(By.xpath("//*[text() = '${ecu}']")) }
        }
    }
}
