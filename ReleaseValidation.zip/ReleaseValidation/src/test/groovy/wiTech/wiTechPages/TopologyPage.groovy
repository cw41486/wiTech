package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By


class TopologyPage extends Page {

    static def ecuModule

    // Xpaths for menu items.
    static at = { $(By.xpath("//h3[text()=' Action Items']")).displayed }


    static content = {

        topologyTab(wait: true) {$(By.xpath("//div[text()=' Topology']"))}
        allDtcTab(wait: true) {$(By.xpath("//div[text()=' All DTCs']"))}
        allFlashesTab(wait: true) {$(By.xpath("//div[text()=' All Flashes']"))}
        recallTab(wait: true){$(By.xpath("//div[text()=' Recalls']"))}
        rrtTab(wait: true){$(By.xpath("//div[text()=' RRTs']"))}
        ecu(wait: true) {$("tspan", text: ecuModule, dy: startsWith("4"))}

    }

}