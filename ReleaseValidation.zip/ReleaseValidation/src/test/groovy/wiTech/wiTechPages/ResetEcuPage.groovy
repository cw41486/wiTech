package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By

class ResetEcuPage extends Page{

    static at = {true}

    static content = {

        resetEcu {$(By.xpath("//*[text() = 'Reset ECU']"))}
        Continue {$(By.xpath("//*[text() = ' Continue']"))}
        resetEcuList {$(By.xpath("/html/body/div/div[1]/div[2]/div[2]/div/div/div[2]/div[3]/div[3]/div/table/tbody"))}
        Close{$(By.xpath("//*[text() = ' Close']"))}

    }
}
