package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By
import wiTech.wiTechModules.ActuatorsModule
import wiTech.wiTechModules.EcuModule
import wiTech.wiTechModules.MiscFunctionModule
import wiTech.wiTechModules.SystemTestsModule


class ECUPage extends Page {

    static ecu
    static flashFile

    static at = { title == "wiTECH" }

    static content = {
        flashTab { $(By.xpath("//*[text() = ' Flash']")) }
        dtcTab { $(By.xpath("//*[text() = ' DTCs']")) }
        dataTab { $(By.xpath("//*[text() = ' Data']")) }
        miscFunctionsTab { $(By.xpath("//*[text() = ' Misc Functions']")) }
        systemsTab {  $(By.xpath("//*[text() = ' System Tests']")) }
        actuatorsTab { $(By.xpath("//*[text() = ' Actuators']")) }
        detailsTab { $(By.xpath("//*[text() = ' Details']")) }
        configTab { $(By.xpath("//*[text() = ' Configuration']")) }
        flash {$('td',class: "mp-table-td-value ng-binding",text: flashFile)}
        functions {module(new MiscFunctionModule(ecu))}
        actuators {module(new ActuatorsModule(ecu))}
        systemsTest{ module(new SystemTestsModule(ecu))}
        dataElement{$(By.xpath("//*[@id=\"dataDisplayTable\"]/tbody/tr"))}
        graphIcon{$(By.xpath("//*[@id=\"dataDisplayTable\"]/tbody/tr//button"))} // all buttons.
        graphSelect{$(By.xpath("//*[@class=\"btn btn-default ng-binding\"]"))}

    }
}
