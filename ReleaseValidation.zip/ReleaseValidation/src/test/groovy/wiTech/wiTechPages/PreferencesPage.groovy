package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By


class PreferencesPage extends Page{

    // Xpath for page elements.
    def dropDownButton = "/html/body/div/div[1]/div[2]/div/div/div/form[2]/div[3]/div/div/button"
    def langList = "/html/body/div/div[1]/div[2]/div/div/div/form[2]/div[3]/div/div/ul"

    // Methods.
    static at = { title == "wiTECH" }

    static content = {

        dropArrow {$(By.xpath(dropDownButton))}
        languages {$(By.xpath(langList))}


    }
}
