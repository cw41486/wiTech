package wiTech.wiTechPages
import geb.Page
import org.openqa.selenium.By


class GraphPage extends Page{


    static at = {true}

    static content = {

        graphDisplay{$(By.xpath("//*[@class='mp-graph']"))}
        exitButton{$(By.xpath("//*[text() = ' Exit']"))}
        pauseButton{$(By.xpath("//*[text() = 'Pause']"))}
        resumeButton{$(By.xpath("//*[text() = 'Resume']"))}
        splitGraph{$(By.xpath("//*[text() = 'Split Graph']"))}
        combineGraph{$(By.xpath("//*[text() = 'Combine Graph']"))}
        graphCheck{$(By.xpath("//table[@class='mp-split-graph-table']"))}
        graphDataList{$(By.xpath("//*[@id=\"graph-legend-scroller\"]/table/tbody"))}
        graphSlider{$(By.xpath("//*[@id=\"graph-time-line\"]/div/div[2]"))}

    }
}
