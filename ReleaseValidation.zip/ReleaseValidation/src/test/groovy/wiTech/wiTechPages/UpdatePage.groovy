package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By

/**
 * Created by SI Admin on 3/1/2016.
 */
class UpdatePage extends Page {
    static at = { title == "Device Manager"}

    static content = {
        updateNowButton {$(By.xpath("//*[text() = 'Update Now']"))}
        updateComplete {$(By.xpath("//*[contains(text(), 'Your device is up-to-date')]"))}
    }
}
