package wiTech.wiTechPages

import geb.Page
import org.openqa.selenium.By


class PageNotFoundPage extends Page{
        static at = {$(By.xpath("//h1[@jsselect = 'heading']")).text() == 'This site can’t be reached'}
}
