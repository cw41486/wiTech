package wiTech.wiTechPages

import geb.Module

/**
 * Created by SI Admin on 3/8/2016.
 */
class FlashTabModule extends Module {
    def getFlashes(){
        def properties = new Properties()
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)
        }
        return properties.getProperty("flashname")
    }

}
