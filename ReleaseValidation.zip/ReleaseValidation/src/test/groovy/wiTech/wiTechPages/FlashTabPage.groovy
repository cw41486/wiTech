package wiTech.wiTechPages
import geb.Page
import org.openqa.selenium.By


class FlashTabPage extends Page {

    def flashTable = "/html/body/div/div[1]/div[2]/div[2]/div/div/div[4]/div[3]/div/div/div/div[3]/div/div/table/tbody/tr"

    static at = {title == "wiTECH"}

    static content = {

        findFlash{$(By.xpath(flashTable))}


    }
}
