package wiTech.wiTechModules

import geb.Module
import org.openqa.selenium.By
import wiTech.wiTechPages.Anvil

/**
 * Created by cwenson on 2/18/2016.
 */
class MiscFunctionModule extends Module {

    def static ecu;

    def routines = getRoutines()

    MiscFunctionModule(ecu){
        this.ecu = ecu
    }

    def List getRoutines(){
        def properties = new Properties()
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)
        }
        def gsFileList = Anvil.listGSFiles(properties,'wiTECH')
        def routineXmlData = []
        gsFileList.each { filename ->
            if (filename =~ "getRoutineData") {
                routineXmlData.add(Anvil.getGSFile(filename, properties, 'wiTECH'))
            } else {

            }
        }
        def miscFunctions = []
        routineXmlData.RoutineData[0].each{
            if((it.ecuAcronym == ecu) && (it.routineClassType == "miscFunc")&&(it.isDeprecated=="false")) {
                if(it.qualifier==""){
                    miscFunctions.add(it.title)
                }
                else{
                    println(ecu+" "+it.title+" had qualifier "+it.qualifier+". skipping.")
                }
            }
            else{ }
        }

        return miscFunctions
    }

    static content = {
        routines.each{
            "${it}" {By.xpath(("//*[text() = '${it}']"))}
        }
        pageRoutines {$(By.xpath("//table[@id='miscFuncsTable']/tbody/tr[@class='ng-scope']"))}
    }
}
