package wiTech.wiTechModules

import geb.Module
import org.openqa.selenium.By
import wiTech.wiTechPages.Anvil

class ActuatorsModule extends Module{

    static ecu
    def actuators = getActuators()
    def actuatorStartOpt = getStartOpts()

    def ActuatorsModule(ecu){
        this.ecu = ecu
    }

    def List getActuators(){
        def properties = new Properties()
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)
        }

        def gsFileList = Anvil.listGSFiles(properties, 'wiTECH')
        def routineXmlData = []
        gsFileList.each { filename ->
            if (filename =~ "getActuatorData") {
                routineXmlData.add(Anvil.getGSFile(filename, properties, 'wiTECH'))
            } else {

            }
        }
        def actuatorList = []
        routineXmlData.ActuatorData[0].each {
            if (it.ecuAcronym =~ ecu) {
                if (actuatorList.contains(it.name)) {

                } else {
                    actuatorList.add(it.name)

                }
            } else {}
        }

        return actuatorList
    }

    def List getStartOpts(){
        def properties = new Properties()
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)
        }
        def gsFileList = Anvil.listGSFiles(properties, 'wiTECH')
        def optionsXmlData = []
        gsFileList.each { filename ->
            if (filename.toString().startsWith("getActuatorStartOptionData_${ecu}")) {
                optionsXmlData.add(Anvil.getGSFile(filename, properties, 'wiTECH'))
            } else {

            }
        }
        def actuatorOptions = []
        optionsXmlData.ActuatorStartOptionData.options.string.each{data ->
            data.each {
                if (actuatorOptions.contains(it)) {

                } else {
                    actuatorOptions.add(it)

                }
            }
        }
        return actuatorOptions
    }

    static content = {
            actuators.each{ act ->
                "${act}" {$(By.xpath("//*[text() = '${act}']"))}
            }
            actuatorStartOpt.each{ option ->
                "${option}"(required: false){$(By.xpath("//*[text() = '${option}']"))}
            }

        pageActuators {$(By.xpath("//table[@id='actuatorTable']/tbody/tr[@class='ng-scope']"))}

        stop{$(By.xpath("//*[text() = 'Stop']"))}
        start{$(By.xpath("//*[text() = 'Start']"))}
        exit{$(By.xpath("//*[text() = ' Exit']"))}

    }
}
