package wiTech.wiTechModules
import geb.Module
import org.openqa.selenium.By
import wiTech.wiTechPages.Anvil

/**
 * Created by cwenson on 3/7/2016.
 */
class SystemTestsModule extends Module{

    def static ecu;

    def routines = getRoutines()

    SystemTestsModule(ecu){
        this.ecu = ecu
    }

    def List getRoutines(){
        def properties = new Properties()
        new File('/ProgramData/geb.properties').withInputStream {
            properties.load(it)
        }
        def gsFileList = Anvil.listGSFiles(properties,'wiTECH')
        def routineXmlData = []
        gsFileList.each { filename ->
            if (filename =~ "getRoutineData") {
                routineXmlData.add(Anvil.getGSFile(filename, properties, 'wiTECH'))
            } else {

            }
        }
        def systemTestFunctions = []
        routineXmlData.RoutineData[0].each{
            if((it.ecuAcronym == ecu) && (it.routineClassType == "systemTest")&&(it.isDeprecated=="false")) {
                if(it.qualifier==""){
                    systemTestFunctions.add(it.title)
                }
                else{
                    println(ecu+" "+it.title+" had qualifier "+it.qualifier+". skipping.")
                }
            }
            else{ }
        }

        return systemTestFunctions
    }


    static content = {
        routines.each{
            "${it}" {By.xpath(("//*[text() = '${it}']"))}
            }
    }
}
