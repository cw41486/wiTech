package wiTech.wiTechModules

import geb.Module


class FlashProcessModule extends Module {
    static content = {

            okButton(wait: true){$("button.btn.btn-default.btn-large.ng-binding", text: contains("OK"))}
            cancelButton(wait: true) {$("button.btn.btn-large.btn-default.ng-binding", text: contains("Cancel"))}
            warningMessage{$("div.mp-flash-accept-warning").children()}
    }
}
