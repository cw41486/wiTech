package wiTech.wiTechModules
import geb.Module


class EcuModule extends Module{

    static content = {
        FlashTab { $("div.ng-binding", text: contains("Flash")) }
        DtcTab { $("div.ng-binding", text: contains("DTCs")) }
        DataTab { $("div.ng-binding", text: contains("Data")) }
        MiscFunctionsTab { $("div.ng-binding", text: contains("Misc Functions")) }
        SystemsTab { $("div.ng-binding", text: contains("System Tests")) }
        ActuatorsTab { $("div.ng-binding", text: contains("Actuators")) }
        DetailsTab { $("div.ng-binding", text: contains("Details")) }
        ConfigTab { $("div.ng-binding", text: contains("Configuration")) }
    }
}
