package wiTech.Processes

import geb.Browser
import org.openqa.selenium.By
import wiTech.*
import wiTech.wiTechPages.*

/**
 * Created by cwenson on 4/20/2016.
 */
class FlightRecorderProcess extends Browser{


    def properties = new Properties()

    FlightRecorderProcess(driver,baseUrl,properties){
        this.driver = driver
        this.baseUrl = baseUrl
        this.properties = properties
    }

    def reuse = new Reusable(driver,baseUrl,properties)

    def start(){
        try {
            beginFlightRecording()
            Thread.sleep(3000)
            deleteFlightRecording()
            Thread.sleep(3000)
            removeFlightRecorder()
            Thread.sleep(3000)
        }
        catch(Throwable t){reuse.log "${t.message}"}
    }


    def beginFlightRecording(){
        def vin = new DiscoveryPage()
        vin.vinNumber = properties.getProperty('vehicle.vin')
        reuse.navigateTo('Flight Recording')
        waitFor{at FlightRecordingPage}
        reuse.log "opened flight recording page"
        // check for previously created template and delete it.
        Thread.sleep(1000)
        def findText
        try {
            findText = templates.children().children().find { it.text() == "0000Geb" }
            findText = findText.text()
        }
        catch (NullPointerException ex) {
            findText = null
        }
        try {
            if ((findText == "0000Geb") && (findText != null)) {
                $("div", title: "View").firstElement().click()  // the template should be at the top of the list.
                Thread.sleep(1000)
                at FlightRecorderTemplatePage
                deleteTemplate.click()
                Thread.sleep(1000)
                assert $(By.xpath("//*[text() = 'Are you sure you want to delete the template?']"))
                deleteTemplate.first().click()
                Thread.sleep(1000)
                assert $(By.xpath("//*[text() = 'Template was deleted successfully.']"))
                $(By.xpath("//*[text() = 'Continue']")).click()
                reuse.log "Flight recording successfully deleted"
                Thread.sleep(1000)
                waitFor { at FlightRecordingPage }

            } else {
            }
        }
        catch(Throwable t){
            reuse.log t.message
        }
        createNewTemplate.click()
        at FlightRecorderTemplatePage
        waitFor{$(By.xpath("//*[text() = ' Create New Template']")).displayed }
        nameBox.value('0000Geb')
        description.value('Leave this at the top')
        Thread.sleep(1000)
        yearButton.click()
        yearList.children().each { year ->
            if (year.text() == '2012') {
                $("${year.tag()}", text: contains("2012")).click()
            } else {
            }
        }
        reuse.log "2012 Selected"
        bodyButton.click()
        Thread.sleep(1000)
        bodyList.children().each { body ->
            if (body.text() == 'JC') {
                $("${body.tag()}", text: contains('JC')).click()
            } else {
            }
        }
        reuse.log "JC Selected"
        ecuButton.click()
        ecuDropdown.children().each { ecu ->
            if (ecu.text() == 'BCM') {
                $("${ecu.tag()}", text: contains('BCM')).click()
            } else {
            }
        }
        reuse.log "BCM selected"
        Thread.sleep(1000)
        elementList.children().each { element ->
            if (element.text() == 'All Doors/Central Locks') {
                $(By.xpath("//*[text() = 'All Doors/Central Locks']")).click()
            } else {
            }
        }
        reuse.log "Element selected"
        add.click()
        Thread.sleep(1000)
        $(By.xpath("//*[text() = 'Top']")).click()
        Thread.sleep(1000)
        saveTemplate.click()
        Thread.sleep(1000)
        assert $(By.xpath("//*[text() = 'New template was created successfully']"))
        $(By.xpath("//*[text() = 'Continue']")).click()       // defined button.
        reuse.log "save successful"
        Thread.sleep(3000)
        reuse.navigateTo('Selection')
        reuse.log "At discovery page"
        waitFor{at DiscoveryPage}
        reuse.log "Selecting scantool"
        waitFor(30){toolSelect}
        toolSelect.click()
        waitFor{at TopologyPage}
        Thread.sleep(3000)
        reuse.navigateTo('Flight Recording')
        waitFor{at FlightRecordingPage}
        reuse.log "Uploading flight recorder mode"
        $("div", title: 'Start').firstElement().click()
        Thread.sleep(10000)
        $('button',text: contains("Start Recording")).click()
        waitFor(60) {
            $("div", text: contains("Flight recording template has been successfully loaded to your device"))
        }
        $(By.xpath("//button[text() = 'Return to Vehicle Selection']")).click()
        reuse.log "Uploaded recording to scantool"
        waitFor{at DiscoveryPage}
        waitFor(30) { trigger }
        trigger.click()
        Thread.sleep(5000)  // wait for recording.
        waitFor(60) { !$(By.xpath("//*[text() = 'Actively Recording']")) }
        reuse.log "Recording completed"
        reuse.navigateTo('Flight Recording Viewer')
        Thread.sleep(1000)
        assert $('h3').text() == 'Flight Recordings'
    }

    def deleteFlightRecording(){
        at FlightRecordingPage
        def result
        try {
            result = recordingsList.children().find { it.text() =~ '0000Geb' }
            result = result.text()
        }
        catch (NullPointerException ex) {
            result = null
        }

        if ((result =~ '0000Geb') && (result != null)) {
            reuse.log "Deleting flight recording"
            recordingDropArrow.click()  // Change this code for when buck is used and not at top of list.
            Thread.sleep(1000)
            deleteRecording.click()
            waitFor { $("div", text: "Are you sure you want to delete flight recording:") }
            $("button", text: "Delete").click()
            waitFor { $("div", text: "Flight recording deleted successfully.") }
            $("button", text: "Close").click()
            reuse.log "Deleted Recording"
        } else {
        }

    }

    def removeFlightRecorder(){
        reuse.log "Releasing tool from flight recorder mode"
        reuse.navigateTo('Selection')
        Thread.sleep(1000)
        waitFor{at DiscoveryPage}
        exitRecording.click()
        Thread.sleep(10000)
        waitFor(30) { toolSelect }
        reuse.log "flight recorder released"
    }
}
