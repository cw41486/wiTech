package wiTech.Processes

import geb.Browser
import org.openqa.selenium.By
import wiTech.Reusable

/**
 * Created by cwenson on 4/19/2016.
 */
class ScantoolConfigProcess extends Browser{

    def properties
    def reuse = new Reusable(driver,baseUrl,properties)
    def anvilScanTools = ['microPODII-Dev','emeaPreTestMicroPOD','microPODII_CCD','microPODII_CCD_2_ABAB',
                         'microPODII_FOUR','microPODII_Rev6']


    ScantoolConfigProcess(driver,baseUrl,properties){
        this.driver = driver
        this.baseUrl = baseUrl
        this.properties = properties
    }

    def start() {
        def failures = []
        at wiTech.Processes.wiTechPages.DiscoveryPage
        devMan.getAt(0).click()
        Thread.sleep(5000)
        withWindow({ title == 'Device Manager' }, page: wiTech.Processes.wiTechPages.DeviceManagerPage, close: true) {
            devDropArrow.first().click()
            waitFor(30) { $(By.xpath("//label[text() = 'Device Name']")) }
            report "Device name appeared"
            Thread.sleep(3000)
            // Change name of scantool
            try {
                def reboot = changeScantoolName('GebTestPod')
                // Reboot device to complete name change
                if(reboot) {
                    rebootScantool()
                    for(int x = 0; x < 180; x++){Thread.sleep(1000)}    // wait for 1.5 minutes
                }
                else{
                    reuse.log "Skipping reboot"
                }
            }
            catch (Throwable t) {
                failures.add(t.message)
            }
        }
        Thread.sleep(3000)
        devMan.getAt(0).click()
        Thread.sleep(5000)
        withWindow({ title == 'Device Manager' }, page: wiTech.Processes.wiTechPages.DeviceManagerPage, close: true) {
            devDropArrow.first().click()
            waitFor(30) { $(By.xpath("//label[text() = 'Device Name']")) }
            report "Device name appeared"
            Thread.sleep(3000)
            // Change name of scantool
            try {
                def reboot = changeScantoolName(properties.getProperty('scanTool.name').toString().replaceAll('-',' '))
                // Reboot device to complete name change
                if(reboot) {
                    rebootScantool()
                    for(int x = 0; x < 180; x++){Thread.sleep(1000)}    // wait for 1.5 minutes
                }
                else{
                    reuse.log "Skipping reboot"
                }
            }
            catch (Throwable t) {
                failures.add(t.message)
            }
        }
        Thread.sleep(3000)
        devMan.getAt(0).click()
        Thread.sleep(5000)
        withWindow({ title == 'Device Manager' }, page: wiTech.Processes.wiTechPages.DeviceManagerPage, close: true){
            try{
                networkSettings()
            }
            catch(Throwable t){
                failures.add(t.message)
            }
        }
        Thread.sleep(3000)
        devMan.getAt(0).click()
        Thread.sleep(5000)
        withWindow({ title == 'Device Manager' }, page: wiTech.Processes.wiTechPages.DeviceManagerPage, close: true){
            try{
                resetScantool()
                for(int x = 0; x < 180; x++){Thread.sleep(1000)} // wait for 1.5 minutes
                reuse.log "Scantool in discovery after resest"
            }
            catch(Throwable t){
                failures.add(t.message)
            }
        }
        Thread.sleep(3000)
        devMan.getAt(0).click()
        Thread.sleep(5000)
        withWindow({ title == 'Device Manager' }, page: wiTech.Processes.wiTechPages.DeviceManagerPage, close: true) {
            try{
                def foundTool = anvilScanTools.find{ it == properties.getProperty('scanTool.name')}
                reuse.log "Reboot Anvil tool only"
                if(foundTool){
                    reuse.log "Anvil tool found, rebooting tool."
                    rebootScantool()
                    for(int x = 0; x < 180; x++){Thread.sleep(1000)} // wait for 1.5 minutes
                }
                else{
                    reuse.log "Skipping reboot process"
                }

            }
            catch(Throwable t){
                failures.add(t.message)
            }
        }

        return failures
    }

    def changeScantoolName(name){
        reuse.log "Changing name of scantool"
        def foundTool = anvilScanTools.find{it == properties.getProperty('scanTool.name')}
            if (foundTool) {
                reuse.log "Anvil scantool deteceted.  Name will not be changed."
                return false
            } else {
                $('input#deviceName').value(name)
                Thread.sleep(3000)
                $('button', text: 'Save').click()
                waitFor(10) { $(By.xpath("//*[contains(text(), 'The device name was updated')]")) }
                report "Device name changed"
                Thread.sleep(5000)
                upArrow.click()
                Thread.sleep(3000)
                return true
            }

    }

    def resetScantool(){
        devDropArrow.getAt(2).click()
        Thread.sleep(3000)
        report "About section information"
        resetButton.click()
        waitFor(30) { $(By.xpath("//h2[text() = 'Are you sure?']")) }
        report "Reboot window appeared"
        resetButton.getAt(1).click()
    }

    def rebootScantool(){
        devDropArrow.getAt(2).click()
        Thread.sleep(1000)
        report "About section information"
        rebootButton.click()
        waitFor(30) { $(By.xpath("//h2[text() = 'Reboot?']")) }
        report "Reboot window appeared"
        rebootButton.getAt(1).click()
    }

    def networkSettings(){
        reuse.log "Network settings"
        devDropArrow.getAt(1).click()
        waitFor(30){$(By.xpath("//*[text() = 'Choose a network']"))}
        reuse.log "Networks Appeared"
        Thread.sleep(3000)
        joinNetwork.click()
        Thread.sleep(3000)
        def foundTool = anvilScanTools.find{ it == properties.getProperty('scanTool.name')}
        if(foundTool){
            ssid.value("anvilpicco")
            pass.value("EthanIsTesting")
        }
        else if(properties.getProperty('scanTool.serialNumber') == 'WSP-32128') {
            ssid.value("RH-CHRYSLER")
            pass.value("1OyjPnIC5gPIJIAHG1rT")
        }
        else{
            ssid.value("WT-RH-1")
            pass.value("1BTzAmR2d3..1z")
        }
        checkBox.getAt(0).click()
        Thread.sleep(3000)
        checkBox.getAt(1).click()
        reuse.log "Entered in a network"
        Thread.sleep(3000)
        checkBox.getAt(1).click()
        Thread.sleep(3000)
        if(foundTool){ // TO BE USED WITH ALL ANVIL PODS
            reuse.log "Anvil scan tool detected.  DO NOT CHANGE NETWORK SETTINGS"
        }
        else if(properties.getProperty('scanTool.serialNumber') == 'WSP-32128'){
            connectButton.click()
            while($(By.xpath("//label[text() = 'Connecting to RH-CHRYSLER']")))
            Thread.sleep(3000)
            joinNetwork.click()
            Thread.sleep(1000)
            cancelButton.click()
            waitFor(30){$(By.xpath("//*[text() = 'Choose a network']"))}
            report "Successfully canceled joining network"
            Thread.sleep(1000)
            manNetwork.click()
            Thread.sleep(1000)
            waitFor(30){networkConnection}
            report "Network Connection appeared"
            Thread.sleep(1000)
            upArrow.click()
            Thread.sleep(1000)
            report "WiFi Connection"
        }
        else{
            connectButton.click()
            while($(By.xpath("//label[text() = 'Connecting to WT-RH-1']")))
                Thread.sleep(3000)
            joinNetwork.click()
            Thread.sleep(1000)
            cancelButton.click()
            waitFor(30){$(By.xpath("//*[text() = 'Choose a network']"))}
            report "Successfully canceled joining network"
            Thread.sleep(1000)
            manNetwork.click()
            Thread.sleep(1000)
            waitFor(30){networkConnection}
            report "Network Connection appeared"
            Thread.sleep(1000)
            upArrow.click()
            Thread.sleep(1000)
            report "WiFi Connection"
        }
}
}
