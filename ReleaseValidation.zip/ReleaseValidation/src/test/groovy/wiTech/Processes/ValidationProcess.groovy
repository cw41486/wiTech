package wiTech.Processes

import geb.Browser
import wiTech.wiTechPages.*
import wiTech.Reusable
import org.openqa.selenium.By

class ValidationProcess extends Browser{

    def properties
    def failures = []

    ValidationProcess(driver,baseUrl,properties){
        this.driver = driver
        this.baseUrl = baseUrl
        this.properties = properties
    }
    def reuse = new Reusable(driver, baseUrl,properties)

    def testAboutPage(){
        reuse.navigateTo('About wiTECH')
        waitFor { at AboutWitechPage }
        reuse.log "Client: ${witechVersion.getAt(0).text()}"
        reuse.log "Server: ${witechVersion.getAt(1).text()}"
        reuse.log "Device OS Version: ${deviceInfo.getAt(0).text()}"
        reuse.log "Device OS Version: ${deviceInfo.getAt(1).text()}"
        reuse.log "Session ID: ${deviceInfo.getAt(2).text()}"
    }

    def testClearAllDtc(){
        $(By.xpath("//button[text() = ' Clear All DTCs']")).click()
        waitFor(10) { $(By.xpath("//h3[@class='ng-binding']")).text() == 'Clear All DTCs' }
        $(By.xpath("//button[text() = 'Continue']")).click()
        waitFor(30) { $(By.xpath("//*[text() = ' DTCs cleared!']")).displayed }
        $(By.xpath("//button[text() = 'Close']")).click()
    }

    def testFreezeFrameData(){
        def freezeFrame = $(By.xpath("//table[@class='mp-table mp-table-hover']//i[@class='fa fa-camera']")).displayed
        if(freezeFrame) {
            $(By.xpath("//button[text() = ' View Freeze Frame']")).click()
            Thread.sleep(5000)
            report "Freeze Frame Page"
            waitFor(30) { $(By.xpath("//button[text() = ' Email Report']")).displayed }
            $(By.xpath("//button[text() = ' Email Report']")).click()
            waitFor(30) { $(By.xpath("//div[@class='panel-heading ng-binding']")).text() == 'Email Report' }
            $(By.xpath("//input[@placeholder = 'User ID']")).value(properties.getProperty('dealerConnect.userid'))
            $(By.xpath("//input[@placeholder = 'Email']")).value('cwenson@dcctools.com')
            Thread.sleep(1000)
            $(By.xpath("//div[text() = ' Add']")).click()
            Thread.sleep(1000)
            $(By.xpath("//div[@id = 'taTextElement7681399037255054']")).value("Geb message test.")
            Thread.sleep(1000)
            $(By.xpath("//button[text() = 'Preview Email']")).click()
            Thread.sleep(1000)
            $(By.xpath("//button[text() = ' Send Report']")).click()
            waitFor(30) {
                $(By.xpath("//p[@class='form-control-static ng-binding']")).text() == 'Report email has been sent.'
            }
            $(By.xpath("//button[text() = 'OK']")).click()
        }
        else{
            reuse.log "No freeze frame data"
        }
        Thread.sleep(3000)
    }

    def testRecalls(){
        recallTab.click()
        Thread.sleep(5000)
        def noRecalls = $('div',class:'mp-list-empty ng-binding ng-scope',text:contains('No Recalls')).displayed
        if(noRecalls){
            reuse.log "No recalls available."
        }
        else {
            waitFor(30) { $(By.xpath("//table[@class = 'mp-table mp-table-hover']")) }
            report "List of recalls"
            $(By.xpath("//table[@class = 'mp-table mp-table-hover']/tbody/tr[@class = 'ng-scope']")).getAt(0).click()
            Thread.sleep(5000)
            withWindow({ $('embed#plugin') }, close: true) {
                Thread.sleep(1000)
                report "Recall window"
            }
        }
    }

    def testFlashes(){
        flashTab.click()
        Thread.sleep(3000)
        def noFlash = $(By.xpath("//*[text()='No flashes available for this ECU.']"))
        if(noFlash){
            reuse.log "No Flash available."
        }
        else {
            $(By.xpath("//button[@class = 'btn btn-default ng-binding ng-scope']")).click()
            Thread.sleep(1000)
            $(By.xpath("//td[@class = 'mp-flash-bulletins']/div/table/tbody/tr[@class = 'ng-scope']")).getAt(0).click()
            Thread.sleep(10000)
            withWindow({ $('embed#plugin') }, close: true) {
                Thread.sleep(1000)
                report "Service bulletin"
            }
            /*      $(By.xpath("//div[@class='table-responsive ng-scope']/table/tbody/tr/td[@class='mp-table-td-value ng-binding']")).getAt(1).click()
        Thread.sleep(3000)
        reuse.doFlashProcess()  // Perform PCM flash
        Thread.sleep(5000)
      $(By.xpath("//button[text() = ' View DTCs']")).click()
  */
        }
        Thread.sleep(3000)
    }

    def testAllFlashes(){
        allFlashesTab.click()
        Thread.sleep(10000)

        if ($(By.xpath("//div[@class='mp-list-empty ng-binding ng-scope']")).displayed) {
            reuse.log "Ecu's up to date"
        } else {
            report "List of flashes"
        }
    }

    def testDtc(classElement){
        def element
        if(classElement == TopologyPage){
            reuse.log "${classElement} - In class element"
            at classElement
            element = allDtcTab
        }
        else{
            reuse.log "${classElement} - In class element"
            at classElement
            element = dtcTab
        }
        element.click()
        Thread.sleep(5000)
        def noDTCs = $(By.xpath("//*[contains(text(),'no DTCs present')]")).displayed
        if(noDTCs){
            reuse.log "no DTCs present"
        }
        else {
            reuse.log "DTCs present"
            $(By.xpath("//div[@class = 'table-responsive ng-scope']/table/tbody/tr[@class = 'ng-scope']")).getAt(0).click()
            // click on first item
            waitFor(30) { $(By.xpath("//div[@class='table-responsive']")) }
            report "DTC tab environment"
            Thread.sleep(3000)
            $(By.xpath("//*[text() = ' Snapshot Data']")).click()
            Thread.sleep(5000)
            def snapshotData = $('button',text: ' Expand All')
            if(snapshotData){
                $('button',text: ' Expand All').click()
                Thread.sleep(1000)
                report "Snapshot data"
                $('button',text: ' Collapse All').click()
            }
            else{
                reuse.log "no snapshot data"
            }
            $(By.xpath("//*[text()=' Environmental Data']")).click()
            Thread.sleep(3000)
            if(classElement == TopologyPage) {
                reuse.navigateTo('Action Items')
                at TopologyPage
                Thread.sleep(3000)
                element = allDtcTab
            }
            else{
                at reuse.selectEcu('PCM')
                Thread.sleep(3000)
                element = dtcTab
            }
            element.click()
            Thread.sleep(3000)
            $(By.xpath("//button[@class='btn btn-default']")).getAt(0).click()
            withWindow({ title == 'fastSearchResults.jsp' }, close: true) {
                waitFor { $(By.xpath("//td[text() = 'Service Information']")).displayed }
                report "SI information"
            }
            Thread.sleep(3000)
            testFreezeFrameData()
            reuse.navigateTo('Action Items')
            Thread.sleep(1000)
            element.click()
            Thread.sleep(1000)
            testClearAllDtc()
            Thread.sleep(1000)
        }
    }

    def testRRT(){
        rrtTab.click()
        Thread.sleep(1000)
        report "RRT details"
    }

    def testSystemsTests(){
        systemsTab.click()
        Thread.sleep(3000)
        def noSystemTests = $(By.xpath("//*[text()='No System Tests available for this ECU.']")).displayed
        if(noSystemTests){
            reuse.log "No system tests available"
        }
        else {
            $(By.xpath("//table[@id = 'sysTestsTable']/tbody/tr[@class = 'ng-scope']/td[@class = 'ng-binding']")).each {
                reuse.log it.text()
            }
        }
    }

    def testMiscFunc(){
        miscFunctionsTab.click()
        Thread.sleep(3000)
        waitFor { at ECUPage }
        def misFunctions = functions.pageRoutines
        misFunctions.each{
            reuse.log it.text()
        }
        waitFor { miscFunctionsTab }
        Thread.sleep(3000)
    }

    def testActuators() {
        actuatorsTab.click()
        Thread.sleep(3000)
        def listOfActuators = []
        actuators.pageActuators.each{listOfActuators.add(it.text())}
        listOfActuators = listOfActuators.subList(0, 1)      // activate 8 actuators.
        listOfActuators.each {
            $(By.xpath("//*[text()='$it']")).click()
            Thread.sleep(2000)
            actuators.start.click()
            Thread.sleep(2000)
            actuators.stop.click()
            Thread.sleep(2000)
            actuators.exit.click()
            Thread.sleep(2000)
        }
    }

    def testDetails(){
        detailsTab.click()
        Thread.sleep(3000)
        report "Details"
    }

    def testConfig(){
        configTab.click()
        Thread.sleep(3000)
        report "Config"
    }

    def performValidation(){
        try {                   // Select the about witech page and verify server and client information
            testAboutPage()
        }
        catch(Throwable t){failures.add("About Page - ${t.message}")}
        reuse.navigateTo('Action Items')
        waitFor{at TopologyPage}
        try {                   //  Click on the all dtc tab in topology page.
            testDtc(TopologyPage)
        }
        catch(Throwable t){failures.add("All DTC - ${t.message}")}
        reuse.navigateTo('Action Items')
        waitFor{at TopologyPage}
        try {                       // Check the all flashes tab.
           testAllFlashes()
        }
        catch(Throwable t){failures.add("All Flashes - ${t.message}")}
        Thread.sleep(3000)
        at TopologyPage
        try {                        // Check the recall tab.
            testRecalls()
        }
        catch(Throwable t){failures.add("Recalls - ${t.message}")}
        Thread.sleep(3000)
        try {                         // check the RRT Tab.
            testRRT()
        }
        catch(Throwable t){failures.add("RRT - ${t.message}")}
        Thread.sleep(3000)
        at reuse.selectEcu('PCM')
        Thread.sleep(3000)
        try {                        // Select ecu and go through DTC tab.
            testFlashes()
        }
        catch(Throwable t){failures.add("Flashes - ${t.message}")}
        at reuse.selectEcu('PCM')
        Thread.sleep(1000)
        try{
           testDtc(ECUPage)
        }
        catch(Throwable t){failures.add("ECU DTC's - ${t.message}")}
        Thread.sleep(3000)
        at reuse.selectEcu('PCM')
        Thread.sleep(3000)
        try{                    // Select data and Graph data elements.
            $(By.xpath("//div[text() = ' Data']")).click()
            waitFor { graphIcon }
            report "Data tab"
            for (int x = 0; x < 3; x++) {
                graphIcon.getAt(x).click()
                Thread.sleep(1000)
            }
            graphSelect.click()
            waitFor(30) { at GraphPage }
            Thread.sleep(10000)
            report "Graph displayed"
            exitButton.click()

        }
        catch(Throwable t){failures.add("Data - ${t.message}")}

        Thread.sleep(3000)
        at ECUPage
        try {                           // Go through Misc Functions
            testMiscFunc()
        }
        catch(Throwable t){failures.add("Misc Func - ${t.message}")}
        try{
            testSystemsTests()
        }
        catch(Throwable t){failures.add("System tests - ${t.message}")}
        Thread.sleep(3000)
        try{                            // Go through Actuators Tab.
            testActuators()
        }
        catch(Throwable t){failures.add("Actuators - ${t.message}")}
        Thread.sleep(3000)
        try {                    // click through details and configuration tabs.
            testDetails()
        }
        catch(Throwable t){failures.add("Details - ${t.message}")}
        try{
            testConfig()
        }
        catch(Throwable t){failures.add("Configuration - ${t.message}")}

        return failures
    }
}
